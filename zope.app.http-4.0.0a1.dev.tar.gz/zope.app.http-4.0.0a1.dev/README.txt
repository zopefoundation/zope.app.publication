zope.app.http
*************

This package implements the simplest HTTP behavior within the Zope
Publisher. It implements all HTTP verbs as views and defines the necessary
HTTP exceptions.
